def mtest():
    print('This is pkgseleton.subpkg1.module1')
