def mtest():
    print('This is pkgskeleton.topmodule2')
