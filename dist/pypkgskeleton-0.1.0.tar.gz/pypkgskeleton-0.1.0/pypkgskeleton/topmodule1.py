import requests  # Not used, but includes an example package dependency (see ../setup.cfg)
def mtest():
    print('This is pypkgskeleton.topmodule1')
