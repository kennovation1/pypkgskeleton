def mtest():
    print('This is pypkgskeleton.topmodule2')
