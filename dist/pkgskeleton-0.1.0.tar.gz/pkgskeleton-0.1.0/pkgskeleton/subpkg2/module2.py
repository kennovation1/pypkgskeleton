def mtest():
    print('This is pkgseleton.subpkg2.module2')
