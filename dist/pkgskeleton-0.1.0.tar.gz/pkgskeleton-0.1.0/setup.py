from setuptools import setup
from setuptools import find_packages

# In the future, we can convert to using setup.cfg instead.
# The package name (pkgskeleton) is the same as the project-level
# directory and the package's code directory. All three of these
# named objects don't necessarily need the same name, but it's
# simpler and common to just keep them all the same.

# The following is a small subset of the available fields.
# For an internal package we don't need most fields, but feel
# free to add others (e.g. license) if you have a need.
# You can omit description, url, author, author_email, but it's
# best to include them if you can.
# find_packages() will look for __init__.py files in the directory
# free to find packages and subpackages. This is easier than having
# to explicitly list them.
setup(name='pkgskeleton',
      version='0.1.0',
      description='A short project description',
      url='http://project-home-page',
      author='Your Name',
      author_email='your_email@some_domain',
      packages=find_packages()
)
